/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

/**
 *
 * @author Administrator
 */
@Entity
@Table(name = "single_costing", catalog = "moneybag", schema = "")
@NamedQueries({
    @NamedQuery(name = "SingleCosting.findAll", query = "SELECT s FROM SingleCosting s")
    , @NamedQuery(name = "SingleCosting.findByScid", query = "SELECT s FROM SingleCosting s WHERE s.scid = :scid")
    , @NamedQuery(name = "SingleCosting.findByMoneySpent", query = "SELECT s FROM SingleCosting s WHERE s.moneySpent = :moneySpent")
    , @NamedQuery(name = "SingleCosting.findByExpenseType", query = "SELECT s FROM SingleCosting s WHERE s.expenseType = :expenseType")
    , @NamedQuery(name = "SingleCosting.findByTimeHistory", query = "SELECT s FROM SingleCosting s WHERE s.timeHistory = :timeHistory")})
public class SingleCosting implements Serializable {

    @Transient
    private PropertyChangeSupport changeSupport = new PropertyChangeSupport(this);

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "Sc_id")
    private Integer scid;
    @Basic(optional = false)
    @Column(name = "moneySpent")
    private double moneySpent;
    @Basic(optional = false)
    @Column(name = "expenseType")
    private String expenseType;
    @Basic(optional = false)
    @Column(name = "timeHistory")
    @Temporal(TemporalType.TIMESTAMP)
    private Date timeHistory;

    public SingleCosting() {
    }

    public SingleCosting(Integer scid) {
        this.scid = scid;
    }

    public SingleCosting(Integer scid, double moneySpent, String expenseType, Date timeHistory) {
        this.scid = scid;
        this.moneySpent = moneySpent;
        this.expenseType = expenseType;
        this.timeHistory = timeHistory;
    }

    public Integer getScid() {
        return scid;
    }

    public void setScid(Integer scid) {
        Integer oldScid = this.scid;
        this.scid = scid;
        changeSupport.firePropertyChange("scid", oldScid, scid);
    }

    public double getMoneySpent() {
        return moneySpent;
    }

    public void setMoneySpent(double moneySpent) {
        double oldMoneySpent = this.moneySpent;
        this.moneySpent = moneySpent;
        changeSupport.firePropertyChange("moneySpent", oldMoneySpent, moneySpent);
    }

    public String getExpenseType() {
        return expenseType;
    }

    public void setExpenseType(String expenseType) {
        String oldExpenseType = this.expenseType;
        this.expenseType = expenseType;
        changeSupport.firePropertyChange("expenseType", oldExpenseType, expenseType);
    }

    public Date getTimeHistory() {
        return timeHistory;
    }

    public void setTimeHistory(Date timeHistory) {
        Date oldTimeHistory = this.timeHistory;
        this.timeHistory = timeHistory;
        changeSupport.firePropertyChange("timeHistory", oldTimeHistory, timeHistory);
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (scid != null ? scid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof SingleCosting)) {
            return false;
        }
        SingleCosting other = (SingleCosting) object;
        if ((this.scid == null && other.scid != null) || (this.scid != null && !this.scid.equals(other.scid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "view.SingleCosting[ scid=" + scid + " ]";
    }

    public void addPropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.addPropertyChangeListener(listener);
    }

    public void removePropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.removePropertyChangeListener(listener);
    }
    
}
