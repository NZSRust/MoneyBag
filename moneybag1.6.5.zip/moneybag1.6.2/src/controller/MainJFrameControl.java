/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;
import javax.swing.JOptionPane;
import view.NewJFrame1;
import model.*;
import view.Addexpense;
import view.NewJFrame;
import view.Edituser;
import view.NewJFrame3;

/**
 *
 * @author Administrator
 */
public class MainJFrameControl {
    private boolean res;
    private Balance bal;
    private Income inc;
    private UserAccount acc;
    
    public MainJFrameControl(){
    }
    
    public void updateuser(Edituser jf, String fname, String lname, String gender, int age, String username, String password, int mainframeid){
     
        try{
            this.setAcc(new UserAccount(fname, lname, gender, age, username, password));
            
            setRes(getAcc().updatedbAccount(mainframeid));
            
            if(isRes()){
                jf.setVisible(false);
                new NewJFrame1(this).setVisible(true);
            }
        }catch(Exception e){
            JOptionPane.showConfirmDialog(null, e);
        }
    }
    
    public void startingSignup(NewJFrame jf, double currentMoney, String frequency, double increase, 
            String fname, String lname, String gender, int age, String username, String password){
        try{
            this.setBal(new Balance(currentMoney));
            this.setInc(new Income(increase, frequency));
            this.setAcc(new UserAccount(fname, lname, gender, age, username, password));
            
            if(!this.getAcc().getUsernameValidity()){
                throw new Exception("Username already exist!");
            }
            
            setRes(getAcc().insertdbAccount());
            
            if(isRes()){
                this.setRes(getBal().insertdbBalance(this.getAcc().getId()));
            }
            if(isRes()){
                this.setRes(getInc().insertdbIncome(this.getAcc().getId()));
            }

            if(isRes()){
                jf.setVisible(false);
                new NewJFrame1(this).setVisible(true);
            }
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Signup Error: " + e.getMessage());
            
        }
    }
    
    public void signingIn(NewJFrame3 jf, String username, String password){
        try{
            this.setAcc(new UserAccount());
            this.getAcc().getUserAuthenticity(username, password);
            
            
            if(this.getAcc().getId() == -1){
                throw new Exception("No ID received!");
            }
            
            this.setBal(new Balance(this.getAcc().getId()));
            this.setInc(new Income(this.getAcc().getId()));

            jf.setVisible(false);
            new NewJFrame1(this).setVisible(true);
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Signing in Error: " + e.getMessage());
        }
        
    }
    
    /**************************************
    public void remakeModel(int id){
        this.setAcc(new UserAccount(id));
        this.setBal(new Balance(id));
        this.setInc(new Income(id));
        
        this.getAcc().getUserInfoWithID();
    }
     * @return 
    ****************************************/
    
    public String convertFrequency(){
        String conv;
        
        switch(this.getInc().getFrequency())
        {
            case "Month":
                conv = "mth";
                break;
            case "Year":
                conv = "yr";
                break;
            case "Second":
                conv = "sec";
                break;
            case "Week":
                conv = "wk";
                break;
            case "Hour":
                conv = "hr";
                break;
            default:
                conv = "n.a.";
        }
        
        return conv;
    }
    
    public void addingExpense(Addexpense ae, String expenseType, double moneySpent){
        try{
            if((this.getBal().getCurrentMoney() - moneySpent) < 0){
                throw new NoMoneyException();
            }
            SingleCosting cos = new SingleCosting(moneySpent, expenseType);
            this.setRes(cos.insertdbSingleCost(this.getAcc().getId()));
            
            if(!this.isRes()){
                throw new Exception("Inserting expense to database failed!");
            }
            System.out.println("Expense Added to database!");
            
            this.setRes(this.getBal().updateBalanceExpense(cos.getMoneySpent(), this.getAcc().getId()));
            
            if(!this.isRes()){
                throw new Exception("Updating Balance failed!");
            }
            ae.setVisible(false);
            new NewJFrame1(this).setVisible(true);
            
        }catch(NoMoneyException e){
            JOptionPane.showMessageDialog(null, e.getMessage());
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Adding Expense Error: " + e.getMessage());
        }
    }
    
    
    public boolean isRes() {
        return res;
    }

    
    public void setRes(boolean res) {
        this.res = res;
    }

    public Balance getBal() {
        return bal;
    }

    public void setBal(Balance bal) {
        this.bal = bal;
    }

    public Income getInc() {
        return inc;
    }

    public void setInc(Income inc) {
        this.inc = inc;
    }

    public UserAccount getAcc() {
        return acc;
    }

    public void setAcc(UserAccount acc) {
        this.acc = acc;
    }
    
   
}
