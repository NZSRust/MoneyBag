/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;

/**
 *
 * @author Administrator
 */
public class Income {
    
    public Income(double increase, String frequency){
        this.increase = increase;
        this.frequency = frequency;
        
    }
    
    public Income(int id){
        this.getInfoWithID(id);
    }
    
    private double incomeMoney;
    private double increase;
    private String frequency;

    public boolean insertdbIncome(int id){
        boolean res = false;
         String st = "Invalid amount input!";
        
        try{
            Connection cn = (Connection) model.connector.getConnection();
            String sql = "insert into income(increase, frequency, incomeMoney, userID) values(?, ?, ?, ?)";
            PreparedStatement ps = cn.prepareStatement(sql);
            
            System.out.println(this.getIncrease() + this.getFrequency() + id);
            ps.setDouble(1, this.getIncrease());
            ps.setString(2, this.getFrequency());
            ps.setDouble(3, this.getIncomeMoney());
            ps.setInt(4, id);
            ps.execute();
            System.out.println("Income saved successfully!");
            res = true;
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e.getMessage());
            res = false;
        }
        return res;
    }
    
    public void getInfoWithID(int id){
        try{
            Connection conn = null;
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/moneybag?zeroDateTimeBehavior=convertToNull","root","");
            Connection cn = (Connection) model.connector.getConnection();
            
            String sql = "SELECT * FROM income WHERE userID = '" + id + "';";
            Statement state = cn.createStatement();
            
            ResultSet rs = state.executeQuery(sql);
            
            if(rs.next()){
                this.setFrequency(rs.getString("frequency"));
                this.setIncomeMoney(rs.getDouble("incomeMoney"));
                this.setIncrease(rs.getDouble("increase"));
            }
            
            System.out.println("Successful info capture!");
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    public double getIncomeMoney() {
        return incomeMoney;
    }

    
    public void setIncomeMoney(double incomeMoney) {
        this.incomeMoney = incomeMoney;
    }

    
    public double getIncrease() {
        return increase;
    }

    
    public void setIncrease(double increase) {
        this.increase = increase;
    }

    
    public String getFrequency() {
        return frequency;
    }

    
    public void setFrequency(String frequency) {
        this.frequency = frequency;
    }
}
