/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import view.NewJFrame1;
import view.NewJFrame3;

/**
 *
 * @author arnejo
 */
public class UserAccount {
    
    public UserAccount(String fname, String lname, String gender, int age, String username, String password){
        this.fname = fname;
        this.lname = lname;
        this.gender = gender;
        this.age = age;
        this.username = username;
        this.password = password;
    }
    
    public UserAccount(int id){
        this.id = id;
    }
    
    public UserAccount(){}
    
    private int id;
    private String fname;
    private String lname;
    private String gender;
    private int age;
    private String username;
    private String password;

    public boolean insertdbAccount(){
        boolean res = false;
        try{
            Connection conn = null;
            PreparedStatement ps;
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/moneybag?zeroDateTimeBehavior=convertToNull","root","");
            ps = conn.prepareStatement("INSERT INTO useraccount(fname,lname,gender,age,username,password) VALUES(?,?,?,?,?,?)");
            
            ps.setString(1, this.getFname());
            ps.setString(2, this.getLname());
            ps.setString(3, this.getGender());
            ps.setInt(4, this.getAge());
            ps.setString(5, this.getUsername());
            ps.setString(6, this.getPassword());
            
            int i = ps.executeUpdate();
            
            System.out.println("User Account saved successfully!");
            res = true;
            
            this.getdbID();
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
        return res;
    }
    public boolean updatedbAccount(int useraccountid){
        boolean res = false;
        Connection conn = null;
            PreparedStatement ps;
        try{
            
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/moneybag?zeroDateTimeBehavior=convertToNull","root","");
            ps = conn.prepareStatement("UPDATE useraccount SET fname = ?, lname  = ?, gender = ?,age = ?,username = ?, password = ? WHERE id = ?");
            
            
            ps.setString(1, this.getFname());
            ps.setString(2, this.getLname());
            ps.setString(3, this.getGender());
            ps.setInt(4, this.getAge());
            ps.setString(5, this.getUsername());
            ps.setString(6, this.getPassword());
            ps.setInt(7, useraccountid);
            
            int i = ps.executeUpdate();
            
            System.out.println("User Account updated successfully!");
            res = true;
            System.out.println("USERACCOUNT MODEL ID = " +useraccountid);
            this.getdbID();
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
            System.out.println("error");
        }
        return res;
    }
    
    
    public void getdbID(){
        
        try{
            Connection conn = null;
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/moneybag?zeroDateTimeBehavior=convertToNull","root","");
            Connection cn = (Connection) model.connector.getConnection();
            
            String sql = "SELECT id FROM useraccount WHERE username = '" + this.getUsername() + "'";
            Statement state = cn.createStatement();
            
            ResultSet rs = state.executeQuery(sql);
            
            
            if(rs.next()){
                this.setId(rs.getInt("id"));
            }
            
            System.out.println("Successful ID capture: " + this.getId());
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    } 
    
    public void getUserAuthenticity(String username, String password){
        Connection conn = null;
        this.setId(-1);
        try{
            
            Class.forName("com.mysql.jdbc.Driver");
            conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/moneybag?zeroDateTimeBehavior=convertToNull","root","");
            Statement st = conn.createStatement();
            
            String sql = "SELECT * FROM useraccount WHERE username = '" + username + "' AND password = '" + password + "'";
            ResultSet rs = st.executeQuery(sql);
            
            if(rs.next()){
                if(rs.getString("username").equals(username) && rs.getString("password").equals(password)){
                    System.out.println("Username authenticated!");
                    this.setAge(rs.getInt("age"));
                    this.setFname(rs.getString("fname"));
                    this.setGender(rs.getString("gender"));
                    this.setLname(rs.getString("lname"));
                    this.setPassword(rs.getString("password"));
                    this.setUsername(rs.getString("username"));
                    this.setId(rs.getInt("id"));
                    if(this.getId() != -1){
                        System.out.println("Successful ID capture: " + this.getId());
                    } else{
                        throw new Exception("no ID captured!");
                    }
                    
                }
            }
            
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "User Authenticity Error: " + e.getMessage());
        }
    }
    
    public void getUserInfoWithID(){
        try{
            Connection conn = null;
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/moneybag?zeroDateTimeBehavior=convertToNull","root","");
            Connection cn = (Connection) model.connector.getConnection();
            
            String sql = "SELECT * FROM useraccount WHERE id = '" + this.getId() + "'";
            Statement state = cn.createStatement();
            
            ResultSet rs = state.executeQuery(sql);
            
            
            if(rs.next()){
                this.setAge(rs.getInt("age"));
                this.setFname(rs.getString("fname"));
                this.setGender(rs.getString("gender"));
                this.setLname(rs.getString("lname"));
                this.setPassword(rs.getString("password"));
                this.setUsername(rs.getString("username"));
            }
            
            System.out.println("Successful info capture!");
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    public boolean getUsernameValidity(){
        boolean valid = true;
        
        try{
            Connection conn = null;
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/moneybag?zeroDateTimeBehavior=convertToNull","root","");
            Connection cn = (Connection) model.connector.getConnection();
            
            String sql = "SELECT * FROM useraccount WHERE username = '" + this.getUsername() + "'";
            Statement state = cn.createStatement();
            
            ResultSet rs = state.executeQuery(sql);
            
            if(rs.next()){
                if(rs.getString("username").equals(this.getUsername())){
                    System.out.println("Username exists!");
                    valid = false;
                }
            }
            
            System.out.println("Successful info capture!");
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
        
        return valid;
    }
        
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFname() {
        return fname;
    }

    public void setFname(String fname) {
        this.fname = fname;
    }

    public String getLname() {
        return lname;
    }

    public void setLname(String lname) {
        this.lname = lname;
    }

    public String getGender() {
        return gender;
    }

 
    public void setGender(String gender) {
        this.gender = gender;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

 
    public String getUsername() {
        return username;
    }


    public void setUsername(String username) {
        this.username = username;
    }


    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
