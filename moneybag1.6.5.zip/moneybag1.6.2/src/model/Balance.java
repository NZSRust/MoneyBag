/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;

/**
 *
 * @author Administrator
 */
public class Balance {
    
    public Balance(double currentMoney){
        
        this.currentMoney = currentMoney;
    }
    
    public Balance(int id){
       this.getInfoWithID(id);
    }
    
    private double currentMoney;

    public boolean insertdbBalance(int id){
         boolean res = false;
        String st = "Invalid amount input!";
        if(this.getCurrentMoney() <= 0){
            JOptionPane.showMessageDialog(null, st);
            res = false;
        }else{
            
            try{
                Connection cn = (Connection) model.connector.getConnection();
                String sql = "INSERT INTO balance(currentMoney, userID) VALUES(?, ?)";
                PreparedStatement ps = cn.prepareStatement(sql);
                
                System.out.println(this.getCurrentMoney());
                ps.setDouble(1, this.getCurrentMoney());
                ps.setInt(2, id);
                ps.execute();
                System.out.println("Balance saved successfully!");
                res = true;
                
            }catch(Exception e){
                JOptionPane.showMessageDialog(null, e.getMessage());
                res = false;
            }
           
        }
        
        return res;
    }
    
    public void getInfoWithID(int id){
        try{
            Connection conn = null;
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/moneybag?zeroDateTimeBehavior=convertToNull","root","");
            Connection cn = (Connection) model.connector.getConnection();
            
            String sql = "SELECT * FROM balance WHERE userID = '" + id + "';";
            Statement state = cn.createStatement();
            
            ResultSet rs = state.executeQuery(sql);
            
            if(rs.next()){
                this.setCurrentMoney(rs.getDouble("currentMoney"));
            }
            
            System.out.println("Successful info capture: " + this.getCurrentMoney());
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    public boolean updateBalanceExpense(double moneySpent, int id){
        boolean res = false;
        
        try{
            double futureBlce = this.getCurrentMoney() - moneySpent;
            
            Connection cn = (Connection) model.connector.getConnection();
            String sql = "UPDATE balance SET currentmoney = ? WHERE userID = ?";
            PreparedStatement ps = cn.prepareStatement(sql);

            System.out.println("Balance before: " + this.getCurrentMoney());
            ps.setDouble(1, futureBlce);
            ps.setInt(2, id);
            ps.executeUpdate();
            this.setCurrentMoney(futureBlce);
            System.out.println("Balance after: " + this.getCurrentMoney());
            
            System.out.println("Balance updated successfully!");
            res = true;
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e.getMessage());
            res = false;
        }

        return res;
        
    }
    
    public double getCurrentMoney() {
        return currentMoney;
    }
    
    public void setCurrentMoney(double currentMoney) {
        this.currentMoney = currentMoney;
    }
}
